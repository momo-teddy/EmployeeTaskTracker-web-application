/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package businesslogic;

import entities.Employee;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Sylvia
 */
@Stateless
public class EmployeeFacade extends AbstractFacade<Employee> implements EmployeeFacadeLocal {

    @PersistenceContext(unitName = "EmpTaskEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public EmployeeFacade() {
        super(Employee.class);
    }
    
    public Employee findByEmail(String email) {
        try {
            return em.createQuery("SELECT e FROM Employee e WHERE e.email = :email", Employee.class)
                     .setParameter("email", email)
                     .getSingleResult();
        } catch (Exception e) {
            return null; // no result found
        }
    }

    // 📋 2. Get all Employees ordered by name
    public List<Employee> findAllOrderedByName() {
        return em.createQuery("SELECT e FROM Employee e ORDER BY e.name ASC", Employee.class)
                 .getResultList();
    }

    // 🔢 3. Count total number of employees
    public Long countEmployees() {
        return em.createQuery("SELECT COUNT(e) FROM Employee e", Long.class)
                 .getSingleResult();
    }
}
    


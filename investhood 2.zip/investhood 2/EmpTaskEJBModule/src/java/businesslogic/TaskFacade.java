/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package businesslogic;

import entities.Employee;
import entities.Task;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Sylvia
 */
@Stateless
public class TaskFacade extends AbstractFacade<Task> implements TaskFacadeLocal {

    @PersistenceContext(unitName = "EmpTaskEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TaskFacade() {
        super(Task.class);
    }
    
    @Override
     public List<Task> findTasksByEmployee(Employee employee) {
        return em.createQuery("SELECT t FROM Task t WHERE t.employee = :employee", Task.class)
                 .setParameter("employee", employee)
                 .getResultList();
    }

    // 🕒 2. Get all pending tasks
    @Override
    public List<Task> findPendingTasks() {
        return em.createQuery("SELECT t FROM Task t WHERE t.status = 'Pending'", Task.class)
                 .getResultList();
    }

    // ✅ 3. Get all completed tasks
    @Override
    public List<Task> findCompletedTasks() {
        return em.createQuery("SELECT t FROM Task t WHERE t.status = 'Completed'", Task.class)
                 .getResultList();
    }

    // 📊 4. Count total tasks
    @Override
    public Long countAllTasks() {
        return em.createQuery("SELECT COUNT(t) FROM Task t", Long.class)
                 .getSingleResult();
    }

    // 📈 5. Count completed tasks
    @Override
    public Long countCompletedTasks() {
        return em.createQuery("SELECT COUNT(t) FROM Task t WHERE t.status = 'Completed'", Long.class)
                 .getSingleResult();
    }

    // ⚙️ 6. Count pending tasks
    @Override
    public Long countPendingTasks() {
        return em.createQuery("SELECT COUNT(t) FROM Task t WHERE t.status = 'Pending'", Long.class)
                 .getSingleResult();
    }
    
}

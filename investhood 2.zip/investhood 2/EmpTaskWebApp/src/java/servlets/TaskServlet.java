/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import businesslogic.EmployeeFacadeLocal;
import businesslogic.TaskFacadeLocal;
import entities.Employee;
import entities.Task;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/TaskServlet")
public class TaskServlet extends HttpServlet {

    @EJB
    private TaskFacadeLocal taskFacade;

    @EJB
    private EmployeeFacadeLocal employeeFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Task> tasks = taskFacade.findAll();
        request.setAttribute("tasks", tasks);
        request.getRequestDispatcher("tasks.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("add".equals(action)) {
            String email = request.getParameter("employeeEmail");
            Employee emp = employeeFacade.findByEmail(email);

            if (emp != null) {
                Task t = new Task();
                t.setTitle(request.getParameter("title"));
                t.setDescription(request.getParameter("description"));
                t.setStatus("Pending");
                t.setCreatedOn(new Date());
                t.setEmployee(emp);
                taskFacade.create(t);
            } else {
                request.setAttribute("error", "No employee found with that email.");
                doGet(request, response); // reload page with error message
                return;
            }

        } else if ("updateStatus".equals(action)) {
            Long taskId = Long.parseLong(request.getParameter("taskId"));
            String status = request.getParameter("status");
            Task t = taskFacade.find(taskId);
            t.setStatus(status);
            taskFacade.edit(t);

        } else if ("delete".equals(action)) {
            Long taskId = Long.parseLong(request.getParameter("taskId"));
            Task t = taskFacade.find(taskId);
            taskFacade.remove(t);
        }

        response.sendRedirect("TaskServlet");
    }
}
